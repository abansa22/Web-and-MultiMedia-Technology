# IT202-Spring2021-project1
SPA to search for Chicago City-Owned Land Inventory data 
