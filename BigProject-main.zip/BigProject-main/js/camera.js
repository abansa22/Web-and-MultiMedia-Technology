var canvas = document.getElementById('canvas');
var context = canvas.getContext('2d');
const video = document.getElementById('video');
const button = document.getElementById('button');
const button1 = document.getElementById('front-camera');
const button2 = document.getElementById('back-camera');
let currentStream;

let isClicked = 0

function stopMediaTracks(stream) {
  stream.getTracks().forEach(track => {
    track.stop();
  });
}

function gotDevices(mediaDevices) {
  buttons = [button1, button2]
  
  let count = 1;

  mediaDevices.forEach(mediaDevice => {
    if (mediaDevice) {
      if (mediaDevice.kind === 'videoinput') {
        if (buttons[count-1] != null) {
          buttons[count-1].value = mediaDevice.deviceId;
          const label = mediaDevice.label || `Camera ${count++}`;
          buttons[count-1].innerHTML = label

          count += 1
        }
      }
    }
  });
}
if(button1){
  button1.addEventListener('click', event => {

    isClicked = 1;
  });
}

if (button2){
  button2.addEventListener('click', event => {
    isClicked = 2;
  });
}

if(button){

  button.addEventListener('click', event => {
    if (typeof currentStream !== 'undefined') {
      stopMediaTracks(currentStream);
    }
    const videoConstraints = {};

    if (isClicked == 0) {
      videoConstraints.facingMode = 'environment';
    }

    else if (isClicked === 1) { // front camera
      videoConstraints.deviceId = { exact: button1.value };
    }
    
    else if (isClicked === 2) { // back camera
      videoConstraints.deviceId = { exact: button2.value };
    }

    const constraints = {
      video: videoConstraints,
      audio: false
    };
    navigator.mediaDevices
      .getUserMedia(constraints)
      .then(stream => {
        currentStream = stream;
        video.srcObject = stream;
        return navigator.mediaDevices.enumerateDevices();
      })
      .then(gotDevices)
      .catch(error => {
        console.error(error);
      });
  });
}


//taking picture
document.getElementById("snap").addEventListener("click", function() {
	context.drawImage(video, 0, 0, 640, 480);
});

navigator.mediaDevices.enumerateDevices().then(gotDevices);