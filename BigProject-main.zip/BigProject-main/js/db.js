//Defining the data base
var db = new Dexie("item_database");
db.version(1).stores({
  items: 'name, description, contact_details, latitude, longitude, photo'
});

//clear the tables when page loads
db.version(2).stores({
  items: 'name, description, contact_details, latitude, longitude, photo'
});

function clearDB() {
  db.items.clear();
  location.reload();
}