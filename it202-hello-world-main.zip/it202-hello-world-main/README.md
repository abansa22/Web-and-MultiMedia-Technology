# it202-hello-world
Hello World

Hi Folks!

I am Ajitesh Bansal from India. I like sports and coding.
I love web technologies and mobile app development as well as databases.
