## Welcome to my IT202 Spring 2021 Activities

Activities will be updated here every week as requested for the course IT202 at UIC. 
GitHub Pages are active and being utilized.
